"""一键启动 micro-ROS agent 与手柄遥控脚本。

    ros2 launch joystick_bringup joystick.launch.py
    ros2 launch joystick_bringup joystick.launch.py serial_dev:=/dev/ttyS5
"""
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    ExecuteProcess,
    RegisterEventHandler,
    TimerAction,
)
from launch.event_handlers import OnProcessStart
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    serial_dev = LaunchConfiguration("serial_dev")
    baudrate = LaunchConfiguration("baudrate")
    teleop_script = LaunchConfiguration("teleop_script")
    startup_delay = LaunchConfiguration("startup_delay")

    # micro-ROS 串口 agent：参数与原先 joystick.sh 一致
    agent = Node(
        package="micro_ros_agent",
        executable="micro_ros_agent",
        arguments=["serial", "-b", baudrate, "--dev", serial_dev],
        output="screen",
        emulate_tty=True,
        respawn=True,
        respawn_delay=3.0,
    )

    # 手柄节点：仍是原来的独立脚本，避免维护两份副本
    teleop = ExecuteProcess(
        cmd=["python3", teleop_script],
        output="screen",
        emulate_tty=True,
        respawn=True,
        respawn_delay=3.0,
    )

    return LaunchDescription([
        DeclareLaunchArgument("serial_dev", default_value="/dev/ttyS4",
                              description="micro-ROS 串口设备"),
        DeclareLaunchArgument("baudrate", default_value="115200"),
        DeclareLaunchArgument(
            "teleop_script",
            default_value="/home/orangepi/workspace/joystick/joystick_teleop.py",
            description="joystick_teleop.py 绝对路径"),
        DeclareLaunchArgument("startup_delay", default_value="2.0",
                              description="agent 启动后延迟多少秒再启动手柄节点"),
        agent,
        RegisterEventHandler(
            OnProcessStart(
                target_action=agent,
                on_start=[TimerAction(period=startup_delay, actions=[teleop])],
            )
        ),
    ])
