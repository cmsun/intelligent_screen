import sys
import time
import pygame

pygame.init()
pygame.joystick.init()

# 检查有多少个手柄连接
joystick_count = pygame.joystick.get_count()
print(f"Number of joysticks: {joystick_count}")

if joystick_count > 0:
    # 创建一个joystick对象
    joystick = pygame.joystick.Joystick(0)  # 通常使用第一个手柄，索引从0开始
    joystick.init()

    #print(f"Joystick name: {joystick.get_name()}")

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        
        print('\033[H\033[J', end='') # 清除终端屏幕

        # 读取游戏手柄的状态
        buttons = joystick.get_numbuttons()
        axes = joystick.get_numaxes()
        hats = joystick.get_numhats()
        print(f"Buttons count: {buttons}")
        print(f"Axes count: {axes}")
        print(f"Hats count: {hats}")

        # 读取每个轴的值（例如摇杆）
        for i in range(axes):
            axis = joystick.get_axis(i)
            print(f"Axis {i}: {axis:.2f}")
        
        # 读取每个按钮的状态
        for i in range(buttons):
            button = joystick.get_button(i)
            print(f"Button {i} pressed: {button}")

        for i in range(hats):
            hat = joystick.get_hat(i)
            print(f"Hat {i}: {hat}")

        time.sleep(0.1)
