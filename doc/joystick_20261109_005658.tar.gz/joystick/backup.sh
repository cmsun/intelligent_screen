#!/bin/bash

BACKUP_PATH="$HOME/Documents"
FILE_NAME=joystick

pushd ..
tar -cvzf $BACKUP_PATH/$FILE_NAME\_$(date "+%Y%m%d_%H%M%S").tar.gz $FILE_NAME ros/src
popd
