#!/bin/bash
# 手动入口：统一交给 ros2 launch；开机自启由 joystick_bringup.service 负责
set -e
source /opt/ros/humble/setup.bash
source "$HOME/workspace/ros/install/setup.bash"
exec ros2 launch joystick_bringup joystick.launch.py "$@"
