# joystick 使用说明

本目录用于启动底盘手柄遥控，主要文件：

| 文件 | 作用 |
| --- | --- |
| `joystick_teleop.py` | 手柄节点：发布 `chassis_msgs/velcmd`、`chassis_msgs/servo_cmd`，订阅 ESP32 上报的状态 |
| `joystick.sh` | 手动启动入口，内部调用 `ros2 launch`（可透传参数） |
| `README.md` | 本说明 |

启动链路：

```
ros2 launch joystick_bringup joystick.launch.py
  ├─ micro_ros_agent    serial /dev/ttyS4 -b 115200
  └─ joystick_teleop.py  agent 启动 2 秒后再启动
```

launch 包位于 `~/workspace/ros/src/joystick_bringup`，两个进程都配置了 `respawn=True, respawn_delay=3.0`，任一崩溃会自动重启。

## 1. 环境

- ROS 2 Humble：`/opt/ros/humble/setup.bash`
- 自定义消息工作区：`~/workspace/ros/install/setup.bash`（内含 `chassis_msgs`、`micro_ros_agent`）
- 串口 `/dev/ttyS4`，用户需属于 `dialout` 组；手柄 `/dev/input/js*`，用户需属于 `input` 组
- 非交互 shell 不会自动读 `.bashrc`，所以手动运行前要显式 `source`，服务里已由 systemd 处理

## 2. 手动使用

> 若 systemd 服务正在运行，先执行 `sudo systemctl stop joystick_bringup.service`，否则 `/dev/ttyS4` 会被占用。

```bash
source /opt/ros/humble/setup.bash
source ~/workspace/ros/install/setup.bash
ros2 launch joystick_bringup joystick.launch.py

# 或者用兼容入口（效果相同）
cd ~/workspace/joystick
./joystick.sh
```

按 `Ctrl-C` 结束，launch 会同时停掉 agent 和 teleop。

### 可覆盖的 launch 参数

```bash
ros2 launch joystick_bringup joystick.launch.py --show-args

ros2 launch joystick_bringup joystick.launch.py serial_dev:=/dev/ttyS5
ros2 launch joystick_bringup joystick.launch.py baudrate:=115200 startup_delay:=2.0
ros2 launch joystick_bringup joystick.launch.py teleop_script:=/path/to/other_teleop.py
./joystick.sh serial_dev:=/dev/ttyS5
```

| 参数 | 默认值 |
| --- | --- |
| `serial_dev` | `/dev/ttyS4` |
| `baudrate` | `115200` |
| `teleop_script` | `/home/orangepi/workspace/joystick/joystick_teleop.py` |
| `startup_delay` | `2.0`（秒，等 agent 就绪） |

### 手柄操作

- 上电默认 `enabled=False`，按 **START（button 11）** 切换使能，再按一次关闭
- button 6 / 8：底盘速度档位 `+` / `-`
- button 7 / 9：舵机 `move_time_ms` `+` / `-`
- 未使能、急停或手柄掉线时不下发 `velcmd` 和 `servo_cmd`
- 摇杆居中且底盘上报的线速度、角速度都为 0 时，不再重复下发零速 `velcmd`

### 确认链路正常

```bash
ros2 topic list | grep chassis_msgs
ros2 topic echo /chassis_msgs/motion
ros2 topic echo /chassis_msgs/servo_status
```

正常应能看到 `/chassis_msgs/{velcmd,servo_cmd,servo_status,imu,xl9535,ir,motion,battery}`；agent 日志里出现 `create_topic` / `create_datareader` 表示 ESP32 已连上。

### 关于屏幕显示

手动运行时终端会每 50 ms 清屏刷新状态。后台服务通过环境变量 `JOYSTICK_DISPLAY=0` 关闭该输出，避免刷满 journal；`joystick_teleop.py` 默认仍为显示，只有显式设为 `0` 才静默。

## 3. 开机自动启动

使用 systemd 系统服务 `joystick_bringup.service`，unit 文件为 `/etc/systemd/system/joystick_bringup.service`。它不依赖登录，开机进入 `multi-user.target` 即启动。

关键配置：

- `User=orangepi`、`WorkingDirectory=/home/orangepi/workspace/joystick`
- `ExecStartPre`：最多等 30 秒直到 `/dev/ttyS4` 出现
- `ExecStart`：先 `source` 两个 `setup.bash`，再 `exec ros2 launch joystick_bringup joystick.launch.py`
- `Restart=always`、`RestartSec=5`：launch 进程退出后 5 秒重启
- `Environment=JOYSTICK_DISPLAY=0` 及 SDL 相关变量

**当前该服务已启用并运行。** 如果被关掉了，重新开启开机自启：

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now joystick_bringup.service
```

常用查看命令：

```bash
systemctl is-enabled joystick_bringup.service     # enabled / disabled
systemctl is-active  joystick_bringup.service     # active / inactive
systemctl status joystick_bringup.service --no-pager
journalctl -u joystick_bringup.service -f         # 实时日志
journalctl -u joystick_bringup.service -n 100 --no-pager
pgrep -af 'micro_ros_agent|joystick_teleop.py'
```

修改了 `joystick_teleop.py` 或 launch 文件后：

```bash
sudo systemctl restart joystick_bringup.service
```

若改动了 launch 包（`package.xml` / `CMakeLists.txt` / launch 文件），先重新编译再重启：

```bash
cd ~/workspace/ros
source /opt/ros/humble/setup.bash
colcon build --packages-select joystick_bringup
source install/setup.bash
sudo systemctl restart joystick_bringup.service
```

## 4. 关掉自动开机启动（保留服务）

只取消开机自启、同时停掉当前运行：

```bash
sudo systemctl disable --now joystick_bringup.service
```

只想临时停一下、不取消自启（下次开机仍会自动启动）：

```bash
sudo systemctl stop joystick_bringup.service
```

之后想恢复：

```bash
sudo systemctl enable --now joystick_bringup.service
```

此时 unit 文件仍在 `/etc/systemd/system/` 下，`joystick.sh` / `ros2 launch` 手动启动方式也照常可用。

## 5. 删除自动开机启动的服务（彻底移除）

```bash
# 1. 停止并取消开机自启
sudo systemctl disable --now joystick_bringup.service

# 2. 删除 unit 文件
sudo rm /etc/systemd/system/joystick_bringup.service

# 3. 让 systemd 重新读取配置并清掉残留状态
sudo systemctl daemon-reload
sudo systemctl reset-failed joystick_bringup.service 2>/dev/null || true

# 4. 确认已移除
systemctl status joystick_bringup.service --no-pager   # 应提示 Unit could not be found
```

删除服务后，仍可用第 2 节的方式手动 `ros2 launch` 启动。

如果连 launch 包也不再需要（可选，删除后将无法用 `ros2 launch joystick_bringup ...`）：

```bash
rm -rf ~/workspace/ros/src/joystick_bringup \
       ~/workspace/ros/build/joystick_bringup \
       ~/workspace/ros/install/joystick_bringup
cd ~/workspace/ros && colcon build
```

## 6. 常见故障

| 现象 | 排查 |
| --- | --- |
| agent 报串口占用 / 打不开 | `pgrep -af micro_ros_agent`，确认服务和手动启动没有同时运行；`ls -l /dev/ttyS4` |
| 串口权限不足 | `groups orangepi` 应含 `dialout`、`input`；缺失时 `sudo usermod -aG dialout,input orangepi` 并重新登录 |
| 手柄识别不到 | `ls -l /dev/input/js*`；看 `journalctl -u joystick_bringup` 里的 pygame 日志 |
| ESP32 没连上 | 检查 `/dev/ttyS4`、波特率 115200、接线；agent 正常时日志有 `create_topic` / `create_datareader` |
| 话题列表为空 | 确认已 `source ~/workspace/ros/install/setup.bash`，且 `ROS_DOMAIN_ID` 与服务端一致 |
| 改了脚本没生效 | `sudo systemctl restart joystick_bringup.service` |
| 日志被刷屏 | 确认服务里 `Environment=JOYSTICK_DISPLAY=0` 未被删掉 |

## 7. 相关文件位置

- 服务定义：`/etc/systemd/system/joystick_bringup.service`
- launch 文件：`~/workspace/ros/src/joystick_bringup/launch/joystick.launch.py`
- 手柄脚本：`~/workspace/joystick/joystick_teleop.py`
- 手动入口：`~/workspace/joystick/joystick.sh`
- 备份：`joystick.sh.bak.<时间戳>`、`joystick_teleop.py.bak*`
