#!/usr/bin/env python3
"""PS2/USB 手柄 -> micro-ROS 底盘 + 总线舵机。

* 底盘：geometry_msgs/Twist -> chassis_msgs/velcmd
    linear.x  [m/s]   前进为正
    angular.z [rad/s] 转向；方向相反时把 angular_sign 设为 -1
* 舵机状态：chassis_msgs/ServoStatus <- chassis_msgs/servo_status（ESP32 每 100ms 上报）
    收到第一条 ready=true 后才认为舵机就绪，并用它锁存目标初值
* 舵机命令：chassis_msgs/ServoCmd -> chassis_msgs/servo_cmd（开环）
    每条命令携带目标角度 angle_deg [deg] 与转动时间 move_time_ms [ms]，
    后者直接决定 BusServo.move_to_angle() 的转动时间，可用 button7/9 调整
    独立定时器按 servo_cmd_hz（默认 20Hz）积分并下发：
      target += servo_sign × axis3 × servo_max_speed_deg_s × dt
    不依赖 ServoStatus.angle_deg 做闭环反馈，位置只在首次握手时锁存一次。
    推杆居中时目标保持不变，舵机停在原处；目标夹紧到 0~170 deg（默认），
    ESP32 的 BusServoClass 驱动层另有一层相同限位作为兜底
* 状态显示：参照 joystick_check.py，每帧清屏并复位光标，数据固定在屏幕左上角
    另外订阅 IMU / XL9535 / IR / Motion / Battery 五类自定义消息，按类别分区显示
* 电流零漂标定：同时按 X(button3)+Y(button4) 进入/保存，B(button1)/A(button0) 以 0.1A
    步进调整；进入时先把 ESP32 的零漂清 0，用万用表读数与程序电流算出目标值后下发，
    ESP32 收到后写入 NVS，并在 BatteryData.current_offset 中周期回读
"""

import os

# SSH / 无图形界面环境下也能初始化 SDL 并读取手柄
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
os.environ.setdefault("SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS", "1")

import time

import pygame
import rclpy
from chassis_msgs.msg import (
    BatteryData,
    ImuData,
    IrData,
    MotionData,
    ServoCmd,
    ServoStatus,
    Xl9535Data,
)
from geometry_msgs.msg import Twist
from rclpy.node import Node
from std_msgs.msg import Float32

_MOTOR_STATES = ("disable", "enable")
_MOTOR_MODES = ("open", "current", "speed", "position")
_BATTERY_STATES = ("idle", "discharging", "charging", "full", "low_battery",
                   "over_current")
# 判断底盘上报速度是否可视为 0 的容差
_SPEED_EPS = 1e-3


def _yn(value):
    return "Y" if value else "N"


def _name(table, index):
    return table[index] if 0 <= index < len(table) else "unknown(%d)" % index


class JoystickTeleop(Node):
    def __init__(self):
        super().__init__("joystick_teleop")

        self.declare_parameter("joy_index", 0)
        self.declare_parameter("topic", "chassis_msgs/velcmd")
        self.declare_parameter("publish_hz", 20.0)     # Twist 底盘速度指令频率
        self.declare_parameter("deadzone", 0.08)
        self.declare_parameter("linear_max", 0.6)       # m/s，与 ESP32 限幅一致
        self.declare_parameter("angular_max", 2.0)      # rad/s
        self.declare_parameter("linear_axis", 1)
        self.declare_parameter("angular_axis", 0)
        self.declare_parameter("linear_sign", -1.0)     # 摇杆上推为负 -> 前进为正
        self.declare_parameter("angular_sign", 1.0)     # 实测转向相反时改成 -1
        self.declare_parameter("start_button", 11)      # START：按下沿切换使能
        self.declare_parameter("speed_up_button", 6)    # button6：底盘速度档位 +
        self.declare_parameter("speed_down_button", 8)  # button8：底盘速度档位 -
        self.declare_parameter("estop_button", -1)      # 急停按钮，-1 表示不启用

        # 舵机：开环按独立定时器积分目标角度，不依赖状态反馈
        self.declare_parameter("servo_status_topic", "chassis_msgs/servo_status")
        self.declare_parameter("servo_cmd_topic", "chassis_msgs/servo_cmd")
        self.declare_parameter("servo_axis", 3)
        self.declare_parameter("servo_max_speed_deg_s", 60.0)  # 推杆到底时最大 60 deg/s
        self.declare_parameter("servo_cmd_hz", 20.0)   # 舵机积分/下发频率，独立于 publish_hz
        self.declare_parameter("servo_move_time_ms", 300)  # 每条命令指定的转动时间 [ms]
        self.declare_parameter("servo_move_time_step_ms", 50)  # button7/9 单次调整量 [ms]
        self.declare_parameter("servo_move_time_up_button", 7)
        self.declare_parameter("servo_move_time_down_button", 9)
        self.declare_parameter("servo_sign", -1.0)      # 上推为负 -> 角度增大
        self.declare_parameter("servo_min_deg", 0.0)    # 目标角度下限
        self.declare_parameter("servo_max_deg", 170.0)  # 目标角度上限
        self.declare_parameter("servo_enabled", True)

        # ESP32 周期上报的五类状态数据（只用于分类显示）
        self.declare_parameter("imu_topic", "chassis_msgs/imu")
        self.declare_parameter("xl9535_topic", "chassis_msgs/xl9535")
        self.declare_parameter("ir_topic", "chassis_msgs/ir")
        self.declare_parameter("motion_topic", "chassis_msgs/motion")
        self.declare_parameter("battery_topic", "chassis_msgs/battery")

        # 电流零漂标定：下发用 std_msgs/Float32，当前值从 BatteryData.current_offset 回读
        self.declare_parameter("battery_offset_topic",
                               "chassis_msgs/battery_current_offset")
        self.declare_parameter("offset_combo_button_x", 3)   # X：与 Y 同时按进入/保存
        self.declare_parameter("offset_combo_button_y", 4)   # Y
        self.declare_parameter("offset_up_button", 1)        # B：零漂 +0.1A
        self.declare_parameter("offset_down_button", 0)      # A：零漂 -0.1A
        self.declare_parameter("offset_step_a", 0.1)         # A，单次调整步长

        def param(name):
            return self.get_parameter(name).value

        self._topic = param("topic")
        self._dz = float(param("deadzone"))
        self._linear_max = float(param("linear_max"))
        self._angular_max = float(param("angular_max"))
        self._linear_axis = int(param("linear_axis"))
        self._angular_axis = int(param("angular_axis"))
        self._linear_sign = float(param("linear_sign"))
        self._angular_sign = float(param("angular_sign"))
        self._start_button = int(param("start_button"))
        self._up_button = int(param("speed_up_button"))
        self._down_button = int(param("speed_down_button"))
        self._estop_button = int(param("estop_button"))
        self._joy_index = int(param("joy_index"))
        self._publish_hz = float(param("publish_hz"))

        self._servo_status_topic = param("servo_status_topic")
        self._servo_cmd_topic = param("servo_cmd_topic")
        self._servo_axis = int(param("servo_axis"))
        self._servo_max_speed = float(param("servo_max_speed_deg_s"))
        self._servo_cmd_hz = float(param("servo_cmd_hz"))
        # ServoCmd.move_time_ms 是 uint16，超范围会在 publish 时抛错，这里先夹住
        self._servo_move_time_ms = max(0, min(65535, int(param("servo_move_time_ms"))))
        self._servo_move_time_step_ms = max(1, min(65535, int(param("servo_move_time_step_ms"))))
        self._move_time_up_button = int(param("servo_move_time_up_button"))
        self._move_time_down_button = int(param("servo_move_time_down_button"))
        self._servo_sign = float(param("servo_sign"))
        self._servo_min_deg = float(param("servo_min_deg"))
        self._servo_max_deg = float(param("servo_max_deg"))
        if self._servo_min_deg > self._servo_max_deg:
            self._servo_min_deg, self._servo_max_deg = (
                self._servo_max_deg, self._servo_min_deg)
        self._servo_enabled = bool(param("servo_enabled"))

        # 默认档位对应旧代码的 12 m/min、28 rad/min
        self._linear_scale = 0.20   # m/s
        self._angular_scale = 0.47  # rad/s

        self._pub = self.create_publisher(Twist, self._topic, 10)
        self._servo_cmd_pub = self.create_publisher(ServoCmd, self._servo_cmd_topic, 10)
        self._battery_offset_topic = param("battery_offset_topic")
        self._offset_x = int(param("offset_combo_button_x"))
        self._offset_y = int(param("offset_combo_button_y"))
        self._offset_up = int(param("offset_up_button"))
        self._offset_down = int(param("offset_down_button"))
        self._offset_step = float(param("offset_step_a"))
        self._battery_offset_pub = self.create_publisher(
            Float32, self._battery_offset_topic, 10)
        self.create_subscription(
            ServoStatus, self._servo_status_topic, self._on_servo_status, 10)
        self.create_subscription(ImuData, param("imu_topic"), self._on_imu_data, 10)
        self.create_subscription(
            Xl9535Data, param("xl9535_topic"), self._on_xl9535_data, 10)
        self.create_subscription(IrData, param("ir_topic"), self._on_ir_data, 10)
        self.create_subscription(
            MotionData, param("motion_topic"), self._on_motion_data, 10)
        self.create_subscription(
            BatteryData, param("battery_topic"), self._on_battery_data, 10)

        pygame.init()
        pygame.joystick.init()
        self._joy = None
        self._open_joystick()

        # 后台服务运行时用 JOYSTICK_DISPLAY=0 关闭 20Hz 清屏输出，避免刷日志
        self._display = os.environ.get("JOYSTICK_DISPLAY", "1") != "0"
        self._enabled = False       # START 切换，默认不使能，上电不会乱跑
        self._estop = False
        self._prev_start = False
        self._prev_up = False
        self._prev_down = False
        self._prev_move_time_up = False
        self._prev_move_time_down = False

        # 电流零漂标定状态：zeroing（自动清零）-> ready（可测量与微调）
        self._offset_mode = False
        self._offset_phase = "idle"
        self._offset_target = 0.0        # A，本地待保存的零漂值
        self._offset_zero_sent_at = 0.0  # 上次发送清零指令的时刻，用于节流
        self._offset_hint = ""
        self._prev_offset_combo = False
        self._prev_offset_up = False
        self._prev_offset_down = False

        # 舵机握手：收到第一条 ready=true 后锁存目标初值；之后完全开环
        self._servo_ready = False
        self._servo_state = None
        self._servo_target_deg = None
        self._last_servo_tick = time.monotonic()

        # 五类 ESP32 上报数据的最新快照；None 表示还没收到
        self._imu_data = None
        self._xl9535_data = None
        self._ir_data = None
        self._motion_data = None
        self._battery_data = None

        self.create_timer(1.0 / max(1.0, self._publish_hz), self._on_timer)
        self.create_timer(1.0 / max(1.0, self._servo_cmd_hz), self._on_servo_timer)
        self.get_logger().info(
            "publish Twist to %s at %.0f Hz; press START(button %d) to enable"
            % (self._topic, self._publish_hz, self._start_button))
        self.get_logger().info(
            "servo cmd %s (open-loop: target += sign*axis%d*%.1f deg/s*dt, "
            "clamp %.1f~%.1f @ %.0f Hz, move_time_ms=%d), waiting for %s"
            % (self._servo_cmd_topic, self._servo_axis, self._servo_max_speed,
               self._servo_min_deg, self._servo_max_deg,
               self._servo_cmd_hz, self._servo_move_time_ms,
               self._servo_status_topic))

    def _open_joystick(self):
        count = pygame.joystick.get_count()
        if count == 0:
            self._joy = None
            self.get_logger().warn("no joystick found, velcmd muted")
            return
        index = min(self._joy_index, count - 1)
        self._joy = pygame.joystick.Joystick(index)
        self._joy.init()
        self.get_logger().info(
            "joystick[%d] %s axes=%d buttons=%d hats=%d"
            % (index, self._joy.get_name(), self._joy.get_numaxes(),
               self._joy.get_numbuttons(), self._joy.get_numhats()))

    def _servo_axis_value(self):
        """返回经死区归一化的 axis3 值 [-1,1]；轴不存在时返回 None。"""
        if not self._servo_enabled or self._servo_axis < 0 or self._joy is None:
            return None
        if self._joy.get_numaxes() <= self._servo_axis:
            return None
        return self._apply_deadzone(
            self._joy.get_axis(self._servo_axis), self._dz)

    def _on_servo_status(self, msg):
        self._servo_state = msg
        if not msg.ready or self._servo_ready:
            return
        # 开环：位置反馈只在首次握手时锁存目标初值，之后不参与控制
        self._servo_ready = True
        self._servo_target_deg = min(
            max(float(msg.angle_deg), self._servo_min_deg),
            self._servo_max_deg)
        self.get_logger().info(
            "servo READY: id=%d position=%d angle=%.1f deg voltage=%.2f V; "
            "open-loop target locked at %.1f deg"
            % (msg.id, msg.position, msg.angle_deg, msg.voltage_v,
               self._servo_target_deg))

    def _on_imu_data(self, msg):
        self._imu_data = msg

    def _on_xl9535_data(self, msg):
        self._xl9535_data = msg

    def _on_ir_data(self, msg):
        self._ir_data = msg

    def _on_motion_data(self, msg):
        self._motion_data = msg

    def _on_battery_data(self, msg):
        self._battery_data = msg

    def _imu_text(self):
        m = self._imu_data
        if m is None:
            return "no data"
        return ("roll=%.1f deg, pitch=%.1f deg, yaw=%.1f deg, yaw_rate=%.1f deg/s"
                % (m.roll_deg, m.pitch_deg, m.yaw_deg, m.yaw_rate_deg_s))

    def _xl9535_text(self):
        m = self._xl9535_data
        if m is None:
            return "no data"
        return ("floor L/LM/RM/R=%s/%s/%s/%s, obstacle head up/down=%s/%s, fan=%s, int=%s"
                % (_yn(m.floor_left), _yn(m.floor_left_middle),
                   _yn(m.floor_right_middle), _yn(m.floor_right),
                   _yn(m.head_up_obstacle), _yn(m.head_down_obstacle),
                   _yn(m.fan_on), _yn(m.int_active)))

    def _ir_text(self):
        m = self._ir_data
        if m is None:
            return "no data"
        if m.timestamp_ms == 0:
            return "no frame yet, active L/R=%s/%s" % (
                _yn(m.left_active), _yn(m.right_active))
        return ("side=%s addr=0x%02X cmd=0x%02X raw=0x%08X valid=%s repeat=%s "
                "t=%d ms, active L/R=%s/%s"
                % ("L" if m.side == 0 else "R", m.address, m.command,
                   m.raw_code, _yn(m.address_valid), _yn(m.repeat),
                   m.timestamp_ms, _yn(m.left_active), _yn(m.right_active)))

    def _motion_text(self):
        m = self._motion_data
        if m is None:
            return "no data"
        return ("cur=(%.2f m/s, %.2f rad/s), rpm L/R=%d/%d, "
                "state L/R=%s/%s, mode L/R=%s/%s, com_err L/R=%s/%s"
                % (m.linear_speed_cur, m.angular_speed_cur,
                   m.left_motor_rpm, m.right_motor_rpm,
                   _name(_MOTOR_STATES, m.left_motor_state),
                   _name(_MOTOR_STATES, m.right_motor_state),
                   _name(_MOTOR_MODES, m.left_motor_mode),
                   _name(_MOTOR_MODES, m.right_motor_mode),
                   _yn(m.left_communication_error),
                   _yn(m.right_communication_error)))

    def _battery_text(self):
        m = self._battery_data
        if m is None:
            return "no data"
        return ("battery=%.2f V, charger=%.2f V, current=%.2f A, power=%.2f W, "
                "soc=%.1f %%, state=%s, charge_en=%s, offset=%.3f A"
                % (m.battery_voltage, m.charger_voltage, m.current, m.power,
                   m.soc, _name(_BATTERY_STATES, m.state),
                   _yn(m.charge_enabled), m.current_offset))

    def _update_servo_cmd(self, dt):
        """开环积分：目标角度按时间累加，不读取位置反馈。"""
        if (not self._servo_enabled or not self._servo_ready
                or self._servo_target_deg is None
                or not self._enabled or self._estop or self._joy is None):
            return

        value = self._servo_axis_value()
        if value is None or value == 0.0:
            return  # 推杆居中：目标保持不变，舵机停在原处

        self._servo_target_deg = min(
            max(self._servo_target_deg
                + self._servo_sign * value * self._servo_max_speed * dt,
                self._servo_min_deg),
            self._servo_max_deg)
        # 推杆有输入时按 servo_cmd_hz 固定频率下发目标角度与转动时间
        cmd = ServoCmd()
        cmd.angle_deg = float(self._servo_target_deg)
        cmd.move_time_ms = self._servo_move_time_ms
        self._servo_cmd_pub.publish(cmd)

    @staticmethod
    def _apply_deadzone(value, dz):
        if abs(value) <= dz:
            return 0.0
        # 去掉死区后重新归一化，避免越过死区时速度突然跳变
        return (value - (dz if value > 0 else -dz)) / (1.0 - dz)

    def _button(self, index):
        return (index >= 0 and self._joy is not None
                and index < self._joy.get_numbuttons()
                and self._joy.get_button(index) == 1)

    def _handle_buttons(self):
        if self._joy is None:
            self._enabled = False
            return

        start = self._button(self._start_button)
        if start and not self._prev_start:
            self._enabled = not self._enabled
            self.get_logger().info(
                "chassis %s" % ("ENABLED" if self._enabled else "DISABLED"))
        self._prev_start = start

        up = self._button(self._up_button)
        if up and not self._prev_up:
            self._linear_scale = min(self._linear_max, self._linear_scale + 0.05)
            self._angular_scale = min(self._angular_max, self._angular_scale + 0.10)
            self.get_logger().info(
                "speed up: %.2f m/s, %.2f rad/s"
                % (self._linear_scale, self._angular_scale))
        self._prev_up = up

        down = self._button(self._down_button)
        if down and not self._prev_down:
            self._linear_scale = max(0.05, self._linear_scale - 0.05)
            self._angular_scale = max(0.10, self._angular_scale - 0.10)
            self.get_logger().info(
                "speed down: %.2f m/s, %.2f rad/s"
                % (self._linear_scale, self._angular_scale))
        self._prev_down = down

        move_time_up = self._button(self._move_time_up_button)
        if move_time_up and not self._prev_move_time_up:
            self._servo_move_time_ms = min(
                65535, self._servo_move_time_ms + self._servo_move_time_step_ms)
            self.get_logger().info(
                "servo move_time_ms up: %d" % self._servo_move_time_ms)
        self._prev_move_time_up = move_time_up

        move_time_down = self._button(self._move_time_down_button)
        if move_time_down and not self._prev_move_time_down:
            self._servo_move_time_ms = max(
                0, self._servo_move_time_ms - self._servo_move_time_step_ms)
            self.get_logger().info(
                "servo move_time_ms down: %d" % self._servo_move_time_ms)
        self._prev_move_time_down = move_time_down

        # 急停是一次性的：触发后需重启节点，避免误碰恢复
        if self._button(self._estop_button) and not self._estop:
            self._estop = True
            self._enabled = False
            self.get_logger().error("ESTOP: velcmd muted, restart node to recover")

    def _publish_offset(self, value):
        msg = Float32()
        msg.data = float(value)
        self._battery_offset_pub.publish(msg)
        self.get_logger().info(
            "send battery current offset %.3f A to %s"
            % (value, self._battery_offset_topic))

    def _handle_offset_buttons(self):
        # X+Y 组合键上升沿：进入标定模式；再次按下则把当前值下发给 ESP32 保存
        combo = (self._button(self._offset_x)
                 and self._button(self._offset_y))
        if combo and not self._prev_offset_combo:
            if not self._offset_mode:
                self._offset_mode = True
                self._offset_phase = "zeroing"
                self._offset_target = 0.0
                self._offset_zero_sent_at = 0.0
                self._offset_hint = "已进入标定：先检查并清零 ESP32 零漂"
                self.get_logger().info(
                    "battery offset calibration: ENTER (X+Y), zeroing ESP32 offset")
            else:
                self._publish_offset(self._offset_target)
                self._offset_mode = False
                self._offset_phase = "idle"
                self._offset_hint = ("已下发 %.3f A，等待 BatteryData 回读确认（NVS）"
                                     % self._offset_target)
                self.get_logger().info(
                    "battery offset calibration: SAVE %.3f A (X+Y)"
                    % self._offset_target)
        self._prev_offset_combo = combo

        # 只有确认 ESP32 零漂已为 0、程序电流是原始值后，才允许 A/B 微调
        up = self._button(self._offset_up)
        down = self._button(self._offset_down)
        if self._offset_mode and self._offset_phase == "ready":
            if up and not self._prev_offset_up:
                self._offset_target = round(
                    self._offset_target + self._offset_step, 3)
                self.get_logger().info(
                    "battery offset target +%.3f -> %.3f A"
                    % (self._offset_step, self._offset_target))
            if down and not self._prev_offset_down:
                self._offset_target = round(
                    self._offset_target - self._offset_step, 3)
                self.get_logger().info(
                    "battery offset target -%.3f -> %.3f A"
                    % (self._offset_step, self._offset_target))
        self._prev_offset_up = up
        self._prev_offset_down = down

    def _update_offset_calibration(self):
        if not self._offset_mode or self._offset_phase != "zeroing":
            return
        data = self._battery_data
        if data is None:
            self._offset_hint = "等待 BatteryData 上报（chassis_msgs/battery）"
            return
        if abs(data.current_offset) > 1e-6:
            # 每 3 秒重发一次 0，直到 ESP32 上报确认，避免每帧都写 NVS
            now = time.monotonic()
            if (self._offset_zero_sent_at == 0.0
                    or now - self._offset_zero_sent_at >= 3.0):
                self._offset_zero_sent_at = now
                self._publish_offset(0.0)
            self._offset_hint = ("ESP32 当前零漂 %.3f A，正在自动清零..."
                                 % data.current_offset)
            return
        # 已回读为 0：程序显示的 current 即未经补偿的原始电流
        self._offset_phase = "ready"
        self._offset_target = 0.0
        self._offset_hint = (
            "零漂已为 0：记万用表读数 A1、屏幕 current 为 A2（A2 带符号）；"
            "零漂值 = (|A1| × -1) - A2；B(+)/A(-) 调 target，再按 X+Y 保存")
        self.get_logger().info(
            "battery offset calibration: ESP32 offset = 0, "
            "offset = -abs(A1) - A2, use B(+)/A(-) then X+Y to save")

    def _offset_text(self):
        esp = ("n/a" if self._battery_data is None
               else "%.3f A" % self._battery_data.current_offset)
        state = ("off" if not self._offset_mode
                 else "ON [%s]" % self._offset_phase)
        return ("mode=%s, esp32 offset=%s, target=%.3f A | %s"
                % (state, esp, self._offset_target,
                   self._offset_hint or "X+Y 进入零漂标定"))

    def _on_servo_timer(self):
        now = time.monotonic()
        # 开环积分用实际 dt；钳到 100ms，避免卡顿后目标角度跳变
        dt = min(max(now - self._last_servo_tick, 0.0), 0.1)
        self._last_servo_tick = now
        # 未使能 / 急停 / 手柄掉线时不下发任何 servo_cmd
        if not self._enabled or self._estop or self._joy is None:
            return
        self._update_servo_cmd(dt)

    def _on_timer(self):
        # 事件泵：更新摇杆状态并处理热插拔
        for event in pygame.event.get():
            if event.type == pygame.JOYDEVICEREMOVED:
                self.get_logger().warn("joystick removed, velcmd muted")
                self._joy = None
                self._enabled = False
            elif event.type == pygame.JOYDEVICEADDED and self._joy is None:
                self._open_joystick()

        self._handle_buttons()
        self._handle_offset_buttons()
        self._update_offset_calibration()

        # 未使能 / 急停 / 手柄掉线时完全静默：不下发任何 velcmd
        active = self._enabled and not self._estop and self._joy is not None
        msg = Twist()

        if active:
            linear = 0.0
            angular = 0.0

            # 沿用旧逻辑：先十字键，后摇杆；摇杆有输入时覆盖十字键
            if self._joy.get_numhats() > 0:
                hat = self._joy.get_hat(0)
                if hat[0] != 0:
                    angular = hat[0] * self._angular_scale
                if hat[1] != 0:
                    linear = hat[1] * self._linear_scale

            if self._joy.get_numaxes() > max(self._linear_axis, self._angular_axis):
                a_lin = self._apply_deadzone(
                    self._joy.get_axis(self._linear_axis), self._dz)
                a_ang = self._apply_deadzone(
                    self._joy.get_axis(self._angular_axis), self._dz)
                if a_lin != 0.0:
                    linear = self._linear_sign * a_lin * self._linear_scale
                if a_ang != 0.0:
                    angular = self._angular_sign * a_ang * self._angular_scale

            msg.linear.x = max(-self._linear_max, min(self._linear_max, linear))
            msg.angular.z = max(-self._angular_max, min(self._angular_max, angular))

        # 指令为 0（Axis0/1 与十字键都居中）时，只在底盘仍在运动或还没收到
        # Motion 快照时继续下发零速；底盘上报线速度、角速度都为 0 后不再重复下发
        cmd_is_zero = msg.linear.x == 0.0 and msg.angular.z == 0.0
        motion = self._motion_data
        chassis_stopped = (motion is not None
                           and abs(motion.linear_speed_cur) <= _SPEED_EPS
                           and abs(motion.angular_speed_cur) <= _SPEED_EPS)
        sent = active and not (cmd_is_zero and chassis_stopped)
        if sent:
            self._pub.publish(msg)

        if self._display:
            # 与 joystick_check.py 一致：清屏并把光标复位到左上角，按类别分区固定显示
            servo_txt = ("waiting" if self._servo_target_deg is None
                         else "%.1f deg" % self._servo_target_deg)
            print('\033[H\033[J', end='')
            print("=== [joystick / velcmd] ===")
            print(f"  enabled: {self._enabled}, estop: {self._estop}, "
                  f"joystick: {'ok' if self._joy else 'none'}")
            print(f"  scale: linear={self._linear_scale:.2f} m/s, "
                  f"angular={self._angular_scale:.2f} rad/s")
            print(f"  cmd: linear={msg.linear.x:.2f} m/s, "
                  f"angular={msg.angular.z:.2f} rad/s, sent={_yn(sent)}")
            print("=== [servo] ===")
            print(f"  target: {servo_txt}")
            print(f"  move_time_ms: {self._servo_move_time_ms} "
                  f"(step={self._servo_move_time_step_ms})")
            print("=== [IMU: euler + yaw rate] ===")
            print("  " + self._imu_text())
            print("=== [XL9535: gpio expander] ===")
            print("  " + self._xl9535_text())
            print("=== [IR: nec frame] ===")
            print("  " + self._ir_text())
            print("=== [Motion: chassis] ===")
            print("  " + self._motion_text())
            print("=== [Battery: bms] ===")
            print("  " + self._battery_text())
            print("=== [Battery offset calibration] ===")
            print("  " + self._offset_text())
            print(f"  keys: X+Y({self._offset_x}+{self._offset_y}) enter/save, "
                  f"B({self._offset_up}) +{self._offset_step:.1f} A, "
                  f"A({self._offset_down}) -{self._offset_step:.1f} A")
            print(f"=== [buttons] START={self._start_button} enable/disable, "
                  f"{self._up_button}/{self._down_button} velcmd scale +/-, "
                  f"{self._move_time_up_button}/{self._move_time_down_button} move_time_ms +/-, "
                  f"estop={self._estop_button}", flush=True)


def main(args=None):
    rclpy.init(args=args)
    node = JoystickTeleop()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        pygame.quit()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
